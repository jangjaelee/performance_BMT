#!/bin/sh

set -u
set -x

block=1024
size=100GB
oper=write


SYSBENCH="/usr/local/sysbench-0.4.12/bin"
#OUTDIR="$HOME/out"
OUTDIR="/opt/output/memory-ddr3-10600r-$size--block_${block}-$oper-with-cpu-E5620-2p"

threads=(1 2 4 8 16 32)

if [ ! -d $OUTDIR ]
then
  mkdir -p $OUTDIR
fi

for ithr in ${threads[@]}; do

  exec >$OUTDIR/memory-ddr3-10600r-$size--block_${block}-$oper-with-cpu-E5620-2p-$ithr 2>&1

  echo "`date` TESTING memory-ddr3-10600r-$size--block_${block}-$oper-with-cpu-E5620-2p-$ithr"
  for i in 1 2; do
    echo "`date` start iteration $i"
    $SYSBENCH/sysbench --test=memory --memory-total-size=$size --memory-scope=global \
    --memory-block-size=$block --memory-oper=$oper --num-threads=$ithr run

  done
 echo "`date` DONE TESTING memory-ddr3-10600r-$size--block_${block}-$oper-with-cpu-E5620-2p-$ithr"
sleep 5
done

