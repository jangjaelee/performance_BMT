
#!/bin/sh

set -u
set -x

SYSBENCH="/usr/local/sysbench-0.4.12/bin"
#OUTDIR="$HOME/out"
OUTDIR="/opt/output"
TEMPDIR="/mnt/ssd"

size=10G
blksize=524288
devices='ext4-intel-520-512K'


if [ ! -f $TEMPDIR/$devices ]
then
    mkdir -p $TEMPDIR/$devices
fi

if [ ! -f $OUTDIR/$devices ]
then
    mkdir -p $OUTDIR/$devices
fi


parallel() {
  for device in $devices; do
    cd $TEMPDIR/$device || exit
    mkdir -p "$OUTDIR/$device" || exit
#   $SYSBENCH/sysbench --test=fileio --file-num=10 --file-total-size=$size "$@" &
    $SYSBENCH/sysbench --test=fileio --file-num=10 --file-total-size=$size "$@" &

  done
  for device in $devices; do
    wait
  done
}
parallel cleanup
parallel prepare
sleep 60  # let drives quiesce after prepare

modes='rndrd seqrd seqwr rndwr rndrw'
for mode in $modes; do
#  for device in $devices; do
    cd $TEMPDIR/$device
    for threads in 1 4 8 16 ; do
      exec >$OUTDIR/$device/$device-$size-$mode-$threads 2>&1
      echo "`date` TESTING direct-$mode-$threads"
      for i in 1 2; do
        echo "`date` start iteration $i"
#        $SYSBENCH/sysbench --test=fileio --file-total-size=$size --file-test-mode=$mode \
#          --max-time=60 --max-requests=100000000 --num-threads=$threads \
#          --init-rng=on --file-num=32 --file-extra-flags=direct \
#          --file-fsync-freq=0 --file-block-size=$blksize run 

        $SYSBENCH/sysbench --test=fileio --file-total-size=$size --file-test-mode=$mode \
          --num-threads=$threads --file-num=10 \
          --max-time=60 --init-rng=on --max-requests=1000000 \
          --file-block-size=$blksize run

      done
      echo "`date` DONE TESTING direct-$mode-$threads"
    done
    sleep 10
#  done
done

