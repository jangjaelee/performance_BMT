#!/bin/sh

set -u
set -x

SYSBENCH="/usr/local/sysbench-0.4.12/bin"
#OUTDIR="$HOME/out"
OUTDIR="/opt/output/cpu-E5620-2p"

prime=100000
threads=(1 2 4 8 16 32)

for ithr in ${threads[@]}; do

  exec >$OUTDIR/cpu-$prime-$ithr 2>&1

  echo "`date` TESTING cpu-$prime-$ithr"
  for i in 1 2; do
    echo "`date` start iteration $i"
    $SYSBENCH/sysbench --test=cpu --cpu-max-prime=$prime --num-threads=$ithr run
  done
 #echo "`date` DONE TESTING direct-$mode-$ithr"
sleep 5
done

